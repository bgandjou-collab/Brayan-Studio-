# Brayan Digital Studio

Site vitrine ultra premium pour Brayan Digital Studio (Yaoundé, Cameroun), construit avec React + Vite, Tailwind CSS v4 et Framer Motion.

## Installation

```bash
npm install
```

## Développement

```bash
npm run dev
```

Le site sera disponible sur `http://localhost:5173`.

## Build de production

```bash
npm run build
npm run preview
```

Les fichiers de production sont générés dans le dossier `dist/`.

## Structure

- `src/components/` — sections de la page (Hero, Services, Portfolio, Process, PremiumPack, WhyChooseUs, Contact, Footer, Navigation, FloatingButtons)
- `src/components/ui/` — composants d'interface réutilisables (shadcn/ui)
- `src/pages/` — pages de l'application (Accueil, 404)
- `src/assets/generated_images/` — visuels utilisés sur le site
- `src/index.css` — thème (couleurs, typographies) et styles globaux Tailwind
