import { motion } from "framer-motion";
import { Check } from "lucide-react";

export function PremiumPack() {
  const features = [
    "Site Web professionnel multi-pages",
    "Design responsive (Mobile, Tablette, PC)",
    "Intégration WhatsApp Business",
    "QR Code personnalisé",
    "Flyer Business & Carte de visite digitale",
    "Intégration Google Maps",
    "Optimisation SEO de base",
    "Support technique prioritaire (1 mois)"
  ];

  return (
    <section className="py-32 relative overflow-hidden">
      {/* Decorative background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-5xl mx-auto glass rounded-sm p-1 border-primary/20">
          <div className="bg-card p-8 md:p-16 rounded-sm relative overflow-hidden">
            {/* Gold Corner Accents */}
            <div className="absolute top-0 left-0 w-16 h-16 border-t-2 border-l-2 border-primary/50" />
            <div className="absolute bottom-0 right-0 w-16 h-16 border-b-2 border-r-2 border-primary/50" />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 mb-6 rounded-full border border-primary/30 bg-primary/10 text-primary text-xs font-medium tracking-wider uppercase">
                  L'Offre Ultime
                </div>
                <h2 className="font-serif text-4xl md:text-5xl font-medium mb-6">
                  Le Pack <span className="text-primary italic">Premium</span>
                </h2>
                <p className="text-foreground/70 mb-8 font-light text-lg">
                  La solution complète pour lancer ou propulser votre activité. Tout ce dont vous avez besoin pour asseoir votre autorité sur le web et hors ligne, conçu avec une précision chirurgicale.
                </p>
                <div className="text-3xl font-serif mb-8 text-white">
                  Sur Devis
                </div>
                <a
                  href="#contact"
                  className="inline-flex items-center justify-center px-8 py-4 bg-primary text-background font-semibold text-sm tracking-wide rounded-sm hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all"
                >
                  Demander cette offre
                </a>
              </div>

              <div className="bg-background/50 rounded-sm p-8 border border-white/5">
                <h3 className="font-serif text-2xl mb-6">Inclus dans le pack :</h3>
                <ul className="space-y-4">
                  {features.map((feature, i) => (
                    <motion.li 
                      key={i}
                      initial={{ opacity: 0, x: -10 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.1 }}
                      className="flex items-start gap-3 text-sm text-foreground/80 font-light"
                    >
                      <Check className="w-5 h-5 text-primary shrink-0" />
                      <span>{feature}</span>
                    </motion.li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
