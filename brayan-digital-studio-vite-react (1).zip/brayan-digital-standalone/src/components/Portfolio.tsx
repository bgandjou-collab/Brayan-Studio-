import { motion } from "framer-motion";
import imgRestaurant from "@assets/generated_images/portfolio-restaurant.jpg";
import imgHotel from "@assets/generated_images/portfolio-hotel.jpg";
import imgClinic from "@assets/generated_images/portfolio-clinic.jpg";
import imgPharmacy from "@assets/generated_images/portfolio-pharmacy.jpg";
import imgSalon from "@assets/generated_images/portfolio-salon.jpg";
import imgLawfirm from "@assets/generated_images/portfolio-lawfirm.jpg";
import imgFashion from "@assets/generated_images/portfolio-fashion.jpg";
import imgGym from "@assets/generated_images/portfolio-gym.jpg";
import imgSchool from "@assets/generated_images/portfolio-school.jpg";
import imgRealestate from "@assets/generated_images/portfolio-realestate.jpg";

export function Portfolio() {
  const prototypes = [
    { title: "L'Atelier Culinaire", category: "Restaurant", img: imgRestaurant },
    { title: "Grand Royal", category: "Hôtel 5 Étoiles", img: imgHotel },
    { title: "Clinique Saint-Paul", category: "Clinique Médicale", img: imgClinic },
    { title: "Pharmacie Nouvelle", category: "Pharmacie", img: imgPharmacy },
    { title: "Élégance Studio", category: "Salon de Coiffure", img: imgSalon },
    { title: "Cabinet Maître K.", category: "Cabinet d'Avocats", img: imgLawfirm },
    { title: "Maison Noir", category: "Boutique Mode", img: imgFashion },
    { title: "Iron Fitness", category: "Salle de Sport", img: imgGym },
    { title: "Académie Excellence", category: "École Privée", img: imgSchool },
    { title: "Prestige Immobilier", category: "Agence Immobilière", img: imgRealestate },
  ];

  return (
    <section id="portfolio" className="py-32 bg-background border-t border-border">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
          <div className="max-w-2xl">
            <h2 className="font-serif text-4xl md:text-5xl font-medium mb-4">
              Nos Prototypes
            </h2>
            <p className="text-foreground/70 font-light text-lg">
              Explorez nos concepts de design exclusifs. Chaque interface est pensée 
              pour convertir et sublimer l'image de marque d'un secteur spécifique.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {prototypes.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: (index % 2) * 0.2 }}
              className="group relative overflow-hidden rounded-sm aspect-[4/3] bg-card"
            >
              <div 
                className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
                style={{ backgroundImage: `url(${item.img})` }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
              
              {/* Badge */}
              <div className="absolute top-4 left-4 px-3 py-1 bg-black/60 backdrop-blur-md border border-white/10 text-[10px] uppercase tracking-widest rounded-sm font-medium">
                Prototype
              </div>

              {/* Content */}
              <div className="absolute bottom-0 left-0 w-full p-8 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                <span className="text-primary text-sm tracking-wider uppercase block mb-2 font-medium">
                  {item.category}
                </span>
                <h3 className="text-2xl font-serif text-white">
                  {item.title}
                </h3>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
