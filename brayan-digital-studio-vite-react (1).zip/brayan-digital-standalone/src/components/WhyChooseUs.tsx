import { motion } from "framer-motion";
import { Paintbrush, Smartphone, Zap, PiggyBank, Star, Headset, ShieldCheck, Search } from "lucide-react";

export function WhyChooseUs() {
  const reasons = [
    { icon: Paintbrush, title: "Design Moderne", desc: "Des interfaces épurées et actuelles." },
    { icon: Smartphone, title: "Sites Responsive", desc: "Parfaits sur mobile, tablette et PC." },
    { icon: Zap, title: "Livraison Rapide", desc: "Respect strict des délais convenus." },
    { icon: PiggyBank, title: "Prix Abordables", desc: "La qualité premium accessible." },
    { icon: Star, title: "Qualité Premium", desc: "Attention obsessionnelle aux détails." },
    { icon: Headset, title: "Support Client", desc: "Toujours à votre écoute après livraison." },
    { icon: ShieldCheck, title: "Sites Sécurisés", desc: "Vos données et celles de vos clients protégées." },
    { icon: Search, title: "SEO Ready", desc: "Optimisés pour Google dès le lancement." },
  ];

  return (
    <section className="py-32 bg-card border-y border-border">
      <div className="container mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="font-serif text-4xl md:text-5xl font-medium mb-4">
            Pourquoi nous choisir ?
          </h2>
          <p className="text-foreground/70 font-light text-lg">
            La différence Brayan Digital.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-x-8 gap-y-12">
          {reasons.map((reason, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="text-center group"
            >
              <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-background flex items-center justify-center border border-border group-hover:border-primary/50 transition-colors">
                <reason.icon className="w-5 h-5 text-primary" />
              </div>
              <h4 className="text-sm font-semibold mb-2">{reason.title}</h4>
              <p className="text-xs text-foreground/60 font-light leading-relaxed">
                {reason.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
