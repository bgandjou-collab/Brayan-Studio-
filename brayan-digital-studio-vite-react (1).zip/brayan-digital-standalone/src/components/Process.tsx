import { motion } from "framer-motion";

export function Process() {
  const steps = [
    { num: "01", title: "Analyse", desc: "Compréhension de vos besoins et objectifs." },
    { num: "02", title: "Conception", desc: "Création de maquettes et architecture." },
    { num: "03", title: "Développement", desc: "Code propre, performant et sur-mesure." },
    { num: "04", title: "Personnalisation", desc: "Intégration de votre identité visuelle." },
    { num: "05", title: "Livraison", desc: "Déploiement et tests rigoureux." },
    { num: "06", title: "Accompagnement", desc: "Support technique et maintenance." },
  ];

  return (
    <section id="process" className="py-32 bg-card relative border-y border-border">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-20">
          <h2 className="font-serif text-4xl md:text-5xl font-medium mb-4">
            Notre Processus
          </h2>
          <p className="text-foreground/70 font-light text-lg">
            Une méthodologie rigoureuse pour garantir l'excellence à chaque étape de votre projet.
          </p>
        </div>

        <div className="relative">
          {/* Horizontal Line */}
          <div className="hidden lg:block absolute top-1/2 left-0 w-full h-[1px] bg-border -translate-y-1/2" />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8 relative z-10">
            {steps.map((step, index) => (
              <motion.div
                key={step.num}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="relative flex flex-col lg:items-center group"
              >
                <div className="hidden lg:flex w-4 h-4 rounded-full border-2 border-primary bg-card z-10 mb-8 absolute top-1/2 -translate-y-1/2 group-hover:scale-150 transition-transform duration-300" />
                
                <div className="lg:mb-[50%] lg:text-center w-full">
                  <span className="text-5xl font-serif text-border font-bold block mb-2 group-hover:text-primary/20 transition-colors">
                    {step.num}
                  </span>
                  <h4 className="text-lg font-medium mb-2">{step.title}</h4>
                  <p className="text-sm text-foreground/60 font-light">
                    {step.desc}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
