export function Footer() {
  return (
    <footer className="bg-black py-8 border-t border-white/5">
      <div className="container mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <span className="font-serif text-lg tracking-wider font-semibold text-white/50">
            BRAYAN<span className="text-primary">.</span>
          </span>
        </div>
        
        <p className="text-xs text-white/40 font-light">
          © {new Date().getFullYear()} Brayan Digital Studio. Tous droits réservés.
        </p>

        <div className="flex items-center gap-4 text-xs text-white/40">
          <a href="https://wa.me/237650745679" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">
            WhatsApp
          </a>
          <span className="w-1 h-1 bg-white/20 rounded-full" />
          <a href="https://instagram.com/brayandigitalstudio" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">
            Instagram
          </a>
        </div>
      </div>
    </footer>
  );
}
