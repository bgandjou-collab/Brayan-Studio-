import { motion } from "framer-motion";
import { Monitor, PenTool, Cpu } from "lucide-react";

export function Services() {
  const services = [
    {
      icon: <Monitor className="w-6 h-6 text-primary" />,
      title: "Sites Web",
      description: "Des vitrines digitales performantes et esthétiques.",
      items: ["Landing Pages", "Portfolio", "Site d'Entreprise", "Restaurant & Hôtel", "Clinique & Médical"]
    },
    {
      icon: <PenTool className="w-6 h-6 text-primary" />,
      title: "Design Graphique",
      description: "Une identité visuelle qui marque les esprits.",
      items: ["Flyers & Affiches", "Cartes de visite", "Invitations", "Menus de restaurant", "Création QR Codes"]
    },
    {
      icon: <Cpu className="w-6 h-6 text-primary" />,
      title: "Solutions Digitales",
      description: "Connectez votre entreprise à vos clients partout, instantanément.",
      items: ["Intégration WhatsApp"]
    }
  ];

  return (
    <section id="services" className="py-32 relative bg-background">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row gap-12 items-end justify-between mb-20">
          <div className="max-w-2xl">
            <h2 className="font-serif text-4xl md:text-5xl font-medium mb-4">
              L'art du <span className="text-primary italic">digital</span>.
            </h2>
            <p className="text-foreground/70 text-lg font-light">
              Une gamme complète de services pour propulser votre entreprise dans l'ère numérique avec élégance et efficacité.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="glass p-8 rounded-sm group hover:border-primary/50 transition-colors duration-500 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-3xl group-hover:bg-primary/10 transition-colors duration-500" />
              
              <div className="w-12 h-12 mb-8 rounded-sm bg-card border border-border flex items-center justify-center group-hover:border-primary/30 transition-colors">
                {service.icon}
              </div>
              
              <h3 className="font-serif text-2xl mb-3">{service.title}</h3>
              <p className="text-foreground/60 text-sm mb-8 font-light h-10">
                {service.description}
              </p>
              
              <ul className="space-y-3">
                {service.items.map((item) => (
                  <li key={item} className="flex items-center text-sm text-foreground/80">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary/50 mr-3" />
                    {item}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
