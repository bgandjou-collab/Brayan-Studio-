import { motion } from "framer-motion";
import { Mail, MapPin, Phone } from "lucide-react";

export function Contact() {
  return (
    <section id="contact" className="py-32 bg-background relative">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Form Side */}
          <div>
            <h2 className="font-serif text-4xl md:text-5xl font-medium mb-6">
              Travaillons <span className="text-primary italic">ensemble</span>.
            </h2>
            <p className="text-foreground/70 font-light mb-12">
              Prêt à transformer votre idée en réalité digitale ? Laissez-nous un message et nous vous répondrons dans les plus brefs délais.
            </p>

            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="contact-nom" className="text-xs uppercase tracking-wider text-foreground/50 font-medium">Nom complet</label>
                  <input 
                    id="contact-nom"
                    type="text" 
                    className="w-full bg-card border border-border px-4 py-3 rounded-sm focus:outline-none focus:border-primary transition-colors text-sm"
                    placeholder="Jean Dupont"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="contact-email" className="text-xs uppercase tracking-wider text-foreground/50 font-medium">Email</label>
                  <input 
                    id="contact-email"
                    type="email" 
                    className="w-full bg-card border border-border px-4 py-3 rounded-sm focus:outline-none focus:border-primary transition-colors text-sm"
                    placeholder="jean@exemple.com"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label htmlFor="contact-telephone" className="text-xs uppercase tracking-wider text-foreground/50 font-medium">Téléphone / WhatsApp</label>
                <input 
                  id="contact-telephone"
                  type="text" 
                  className="w-full bg-card border border-border px-4 py-3 rounded-sm focus:outline-none focus:border-primary transition-colors text-sm"
                  placeholder="+237 ..."
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="contact-message" className="text-xs uppercase tracking-wider text-foreground/50 font-medium">Message</label>
                <textarea 
                  id="contact-message"
                  rows={4}
                  className="w-full bg-card border border-border px-4 py-3 rounded-sm focus:outline-none focus:border-primary transition-colors text-sm resize-none"
                  placeholder="Parlez-nous de votre projet..."
                ></textarea>
              </div>
              <button 
                type="submit"
                className="w-full bg-primary text-background font-semibold tracking-wide text-sm py-4 rounded-sm hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all"
              >
                Envoyer le message
              </button>
            </form>
          </div>

          {/* Info Side */}
          <div className="flex flex-col justify-between">
            <div className="glass p-8 rounded-sm space-y-8 mb-8">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-sm bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-medium mb-1">Localisation</h4>
                  <p className="text-sm text-foreground/60 font-light">Yaoundé, Cameroun</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-sm bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-medium mb-1">WhatsApp & Appel</h4>
                  <a href="tel:+237650745679" className="text-sm text-foreground/60 font-light hover:text-primary transition-colors">
                    +237 650 745 679
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-sm bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-medium mb-1">Email</h4>
                  <a href="mailto:bgandjou@gmail.com" className="text-sm text-foreground/60 font-light hover:text-primary transition-colors">
                    bgandjou@gmail.com
                  </a>
                </div>
              </div>
            </div>

            {/* Map Placeholder */}
            <div className="relative h-[250px] bg-card border border-border rounded-sm overflow-hidden flex items-center justify-center group">
              <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10" />
              <div className="relative z-10 flex flex-col items-center gap-2">
                <MapPin className="w-8 h-8 text-primary opacity-50 group-hover:opacity-100 transition-opacity" />
                <span className="font-serif text-lg text-foreground/70">Yaoundé, Cameroun</span>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
}
