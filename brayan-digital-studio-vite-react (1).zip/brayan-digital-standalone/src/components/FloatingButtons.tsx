import { useState, useEffect } from "react";
import { MessageCircle, Phone, ArrowUp } from "lucide-react";

export function FloatingButtons() {
  const [showTopBtn, setShowTopBtn] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowTopBtn(window.scrollY > 500);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3">
      {/* Scroll to Top */}
      <button
        onClick={scrollToTop}
        className={`w-12 h-12 rounded-full bg-card border border-border flex items-center justify-center text-foreground hover:bg-primary hover:text-background hover:border-primary transition-all duration-300 shadow-lg ${
          showTopBtn ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10 pointer-events-none"
        }`}
        aria-label="Retour en haut"
      >
        <ArrowUp className="w-5 h-5" />
      </button>

      {/* Phone */}
      <a
        href="tel:+237650745679"
        className="w-12 h-12 rounded-full bg-card border border-border flex items-center justify-center text-foreground hover:bg-white hover:text-black transition-all duration-300 shadow-lg"
        aria-label="Appeler"
      >
        <Phone className="w-5 h-5" />
      </a>

      {/* WhatsApp */}
      <a
        href="https://wa.me/237650745679"
        target="_blank"
        rel="noopener noreferrer"
        className="w-14 h-14 rounded-full bg-[#25D366] text-white flex items-center justify-center hover:scale-110 hover:shadow-[0_0_15px_rgba(37,211,102,0.5)] transition-all duration-300 shadow-lg"
        aria-label="WhatsApp"
      >
        <MessageCircle className="w-7 h-7" />
      </a>
    </div>
  );
}
